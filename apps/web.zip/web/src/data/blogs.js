const blogs = [
  {
    id: 1,
    slug: "top-50-react-interview-questions-2026",
    title: "Top 50 React Interview Questions 2026",
    description:
      "Most asked React interview questions with answers for freshers and experienced developers.",
    image: "/react-blog.jpg",
    author: "GotPlaced Team",
    category: "React",
    date: "16 July 2026",
    readTime: "10 min read",

    content: `
React is one of the most popular JavaScript libraries used for building modern web applications.

In this guide you'll learn the top React interview questions that companies like TCS, Infosys, Accenture, Deloitte, Capgemini and Cognizant frequently ask.

1. What is React?
React is an open-source JavaScript library developed by Meta for building user interfaces.

2. What is JSX?
JSX allows developers to write HTML-like syntax inside JavaScript.

3. What is Virtual DOM?
Virtual DOM is a lightweight copy of the real DOM that improves performance.

4. Difference between State and Props?
Props are passed from parent to child while State is managed inside the component.

5. What are React Hooks?
Hooks allow functional components to use state and lifecycle methods.

More questions will be added soon...
`,
  },

  {
    id: 2,
    slug: "best-resume-format-for-freshers",
    title: "Best Resume Format for Freshers",
    description:
      "Create an ATS-friendly resume that helps you get interview calls.",
    image: "/resume-blog.jpg",
    author: "GotPlaced Team",
    category: "Resume",
    date: "16 July 2026",
    readTime: "8 min read",

    content: `
A resume is your first impression during placements.

In this guide you'll learn:

• ATS Friendly Resume Format

• Resume Sections

• Resume Projects

• Skills

• Certifications

• Common Resume Mistakes

More resume tips coming soon...
`,
  },
  {
  id: 3,
  slug: "tcs-nqt-preparation-guide-2026",
  title: "TCS NQT Preparation Guide 2026",
  description:
    "Complete TCS NQT preparation guide with syllabus, aptitude, coding questions and interview tips.",
  image: "/tcs-blog.jpg",
  author: "GotPlaced Team",
  category: "Placement",
  date: "16 July 2026",
  readTime: "12 min read",

  content: `
# TCS NQT Preparation Guide 2026

TCS National Qualifier Test (NQT) is one of the most popular hiring exams for freshers.

## Eligibility

• Final Year Students

• Fresh Graduates

## Exam Pattern

• Verbal Ability

• Numerical Ability

• Reasoning Ability

• Coding

## Preparation Tips

✔ Practice Aptitude Daily

✔ Solve Previous Year Papers

✔ Learn DSA Basics

✔ Practice Coding Questions

## Interview Tips

• Revise Resume

• Practice HR Questions

• Learn OOP Concepts

• Improve Communication

## Conclusion

Consistent preparation and mock tests can significantly improve your chances of clearing TCS NQT.
`,
},
];

export default blogs;